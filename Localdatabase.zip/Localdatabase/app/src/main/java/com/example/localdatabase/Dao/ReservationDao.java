package com.example.localdatabase.Dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.localdatabase.Entity.Reservation;

import java.util.List;

@Dao
public interface ReservationDao {

    @Query("SELECT * FROM reservations ORDER BY reservation_time DESC")
    List<Reservation> getAllReservations();

    @Insert
    void insertReservation(Reservation reservation);

    @Delete
    void deleteReservation(Reservation reservation);

    @Query("DELETE FROM reservations")
    void deleteAllReservations();
}

