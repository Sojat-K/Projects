package com.example.localdatabase.Dao;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.localdatabase.Entity.Participant;

import java.util.List;

@Dao
public interface ParticipantDao {

    @Query("SELECT * FROM participants WHERE reservation_id = :reservationId")
    List<Participant> getParticipantsForReservation(int reservationId);

    @Insert
    void insertParticipant(Participant participant);

    @Delete
    void deleteParticipant(Participant participant);

    @Query("DELETE FROM participants")
    void deleteAllParticipants();
}

