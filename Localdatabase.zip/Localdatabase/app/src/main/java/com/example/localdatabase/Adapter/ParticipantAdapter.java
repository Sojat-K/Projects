package com.example.localdatabase.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.example.localdatabase.Entity.Participant;
import com.example.localdatabase.R;

public class ParticipantAdapter extends ListAdapter<Participant, ParticipantAdapter.ParticipantHolder> {

    public ParticipantAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Participant> DIFF_CALLBACK = new DiffUtil.ItemCallback<Participant>() {
        @Override
        public boolean areItemsTheSame(@NonNull Participant oldItem, @NonNull Participant newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Participant oldItem, @NonNull Participant newItem) {
            return oldItem.getName().equals(newItem.getName()) &&
                    oldItem.isAttending() == newItem.isAttending();
        }
    };

    @NonNull
    @Override
    public ParticipantHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.participant_item, parent, false);
        return new ParticipantHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ParticipantHolder holder, int position) {
        Participant currentParticipant = getItem(position);
        holder.nameTextView.setText(currentParticipant.getName());
        holder.attendingCheckBox.setChecked(currentParticipant.isAttending());
    }

    class ParticipantHolder extends RecyclerView.ViewHolder {
        private TextView nameTextView;
        private CheckBox attendingCheckBox;

        public ParticipantHolder(@NonNull View itemView) {
            super(itemView);
            nameTextView = itemView.findViewById(R.id.nameTextView);
            attendingCheckBox = itemView.findViewById(R.id.attendingCheckBox);
        }
    }
}
