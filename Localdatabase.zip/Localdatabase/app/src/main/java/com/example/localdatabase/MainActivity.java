package com.example.localdatabase;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.localdatabase.Entity.Reservation;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ReservationAdapter reservationAdapter;
    private ReservationViewModel reservationViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        reservationAdapter = new ReservationAdapter();
        recyclerView.setAdapter(reservationAdapter);

        reservationViewModel = new ViewModelProvider(this).get(ReservationViewModel.class);
        reservationViewModel.getAllReservations().observe(this, new Observer<List<Reservation>>() {
            @Override
            public void onChanged(List<Reservation> reservations) {
                reservationAdapter.submitList(reservations);
            }
        });

        FloatingActionButton addReservationButton = findViewById(R.id.addReservationButton);
        addReservationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddReservationDialog();
            }
        });
    }

    private void showAddReservationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Reservation");

        View view = getLayoutInflater().inflate(R.layout.dialog_add_reservation, null);
        final EditText titleEditText = view.findViewById(R.id.titleEditText);
        final EditText timeEditText = view.findViewById(R.id.timeEditText);
        final EditText lengthEditText = view.findViewById(R.id.lengthEditText);

        builder.setView(view);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String title = titleEditText.getText().toString().trim();
                String timeString = timeEditText.getText().toString().trim();
                int length = Integer.parseInt(lengthEditText.getText().toString().trim());

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                Date date = new Date();
                try {
                    date = format.parse(timeString);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                Reservation reservation = new Reservation(title, date, length);
                reservationViewModel.insertReservation(reservation);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
