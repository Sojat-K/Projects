package com.example.localdatabase;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import com.example.localdatabase.Dao.ParticipantDao;
import com.example.localdatabase.Dao.ReservationDao;
import com.example.localdatabase.Database.ReservationDatabase;
import com.example.localdatabase.Entity.Participant;
import com.example.localdatabase.Entity.Reservation;

import java.util.List;

public class ReservationRepository {
    private ReservationDao mReservationDao;
    private ParticipantDao mParticipantDao;
    private LiveData<List<Reservation>> mAllReservations;

    public ReservationRepository(Application application) {
        ReservationDatabase db = ReservationDatabase.getDatabase(application);
        mReservationDao = db.reservationDao();
        mParticipantDao = db.participantDao();
        mAllReservations = (LiveData<List<Reservation>>) mReservationDao.getAllReservations();
    }

    LiveData<List<Reservation>> getAllReservations() {
        return mAllReservations;
    }

    public void insert(Reservation reservation) {
        new InsertReservationAsyncTask(mReservationDao).execute(reservation);
    }

    public void delete(Reservation reservation) {
        new DeleteReservationAsyncTask(mReservationDao, mParticipantDao).execute(reservation);
    }

    private static class InsertReservationAsyncTask extends AsyncTask<Reservation, Void, Void> {
        private ReservationDao mAsyncTaskDao;

        InsertReservationAsyncTask(ReservationDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Reservation... params) {
            mAsyncTaskDao.insertReservation(params[0]);
            return null;
        }
    }

    private static class DeleteReservationAsyncTask extends AsyncTask<Reservation, Void, Void> {
        private ReservationDao mReservationDao;
        private ParticipantDao mParticipantDao;

        DeleteReservationAsyncTask(ReservationDao reservationDao, ParticipantDao participantDao) {
            mReservationDao = reservationDao;
            mParticipantDao = participantDao;
        }

        @Override
        protected Void doInBackground(final Reservation... params) {
            // delete all participants for the reservation
            int reservationId = params[0].getId();
            List<Participant> participants = mParticipantDao.getParticipantsForReservation(reservationId);
            for (Participant participant : participants) {
                mParticipantDao.deleteParticipant(participant);
            }

            // delete the reservation
            mReservationDao.deleteReservation(params[0]);

            return null;
        }
    }
}
