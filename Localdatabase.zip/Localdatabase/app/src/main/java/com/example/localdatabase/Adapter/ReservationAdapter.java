package com.example.localdatabase.Adapter;

import static java.security.AccessController.getContext;
import static java.util.Objects.requireNonNull;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.localdatabase.Entity.Participant;
import com.example.localdatabase.Entity.Reservation;
import com.example.localdatabase.R;
import com.example.localdatabase.ReservationViewModel;

import java.util.List;

public class ReservationAdapter extends ListAdapter<Reservation, ReservationAdapter.ReservationHolder> {

    public ReservationAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Reservation> DIFF_CALLBACK = new DiffUtil.ItemCallback<Reservation>() {
        @Override
        public boolean areItemsTheSame(@NonNull Reservation oldItem, @NonNull Reservation newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Reservation oldItem, @NonNull Reservation newItem) {
            return oldItem.getTitle().equals(newItem.getTitle()) &&
                    oldItem.getReservationTime().equals(newItem.getReservationTime()) &&
                    oldItem.getReservationLength() == newItem.getReservationLength() &&
                    oldItem.isHasCompleted() == newItem.isHasCompleted();
        }
    };

    @NonNull
    @Override
    public ReservationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reservation_item, parent, false);
        return new ReservationHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservationHolder holder, int position) {
        Reservation currentReservation = getItem(position);
        holder.titleTextView.setText(currentReservation.getTitle());
        holder.timeTextView.setText(currentReservation.getReservationTimeString());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReservationDetailsDialog(currentReservation);
            }
        });
    }

    public Reservation getReservationAt(int position) {
        return (Reservation) getItem(position);
    }

    @Override
    public boolean areAllItemsEnabled() {
        return false;
    }

    @Override
    public boolean isEnabled(int i) {
        return false;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {

    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        return null;
    }

    @Override
    public int getItemViewType(int i) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 0;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }

    class ReservationHolder extends RecyclerView.ViewHolder {
        private TextView titleTextView;
        private TextView timeTextView;

        public ReservationHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
            timeTextView = itemView.findViewById(R.id.timeTextView);
        }
    }

    private void showReservationDetailsDialog(Reservation reservation) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireNonNull(getContext()));
        builder.setTitle(reservation.getTitle());

        View view = getLayoutInflater().inflate(R.layout.reservation_layout, null);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView timeTextView = view.findViewById(R.id.time);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView lengthTextView = view.findViewById(R.id.length);
        RecyclerView participantsRecyclerView = view.findViewById(R.id.participantsRecyclerView);

        timeTextView.setText(reservation.getReservationTimeString());
        lengthTextView.setText(reservation.getReservationLengthString());

        ParticipantAdapter participantAdapter = new ParticipantAdapter();
        participantsRecyclerView.setLayoutManager(new LinearLayoutManager(requireNonNull(getContext())));
        participantsRecyclerView.setAdapter(ParticipantAdapter);
        ReservationViewModel.getParticipantsForReservation(reservation.getId()).observe((LifecycleOwner) getContext(), new Observer<List<Participant>>() {
            @Override
            public void onChanged(List<Participant> participants) {
                ParticipantAdapter.submitList(participants);
            }
        });

        builder.setView(view);

        builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private LayoutInflater getLayoutInflater() {
    }
}

