package com.example.localdatabase.Entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "participants",
        foreignKeys = @ForeignKey(entity = Reservation.class,
                parentColumns = "id",
                childColumns = "reservation_id",
                onDelete = ForeignKey.SET_NULL))
public class Participant {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "reservation_id")
    private int reservationId;

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "attending")
    private boolean attending;

    public Participant(int reservationId, String name, boolean attending) {
        this.reservationId = reservationId;
        this.name = name;
        this.attending = attending;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAttending() {
        return attending;
    }

    public void setAttending(boolean attending) {
        this.attending = attending;
    }
}

