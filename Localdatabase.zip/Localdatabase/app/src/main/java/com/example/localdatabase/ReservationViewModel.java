package com.example.localdatabase;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.localdatabase.Entity.Reservation;

import java.util.List;

public class ReservationViewModel extends AndroidViewModel {

    private ReservationRepository mRepository;
    private LiveData<List<Reservation>> mAllReservations;

    public ReservationViewModel(Application application) {
        super(application);
        mRepository = new ReservationRepository(application);
        mAllReservations = mRepository.getAllReservations();
    }

    LiveData<List<Reservation>> getAllReservations() {
        return mAllReservations;
    }

    public void insert(Reservation reservation) {
        mRepository.insert(reservation);
    }

    public void delete(Reservation reservation) {
        mRepository.delete(reservation);
    }
}

