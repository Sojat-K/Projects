package com.example.localdatabase.Database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.localdatabase.Dao.ParticipantDao;
import com.example.localdatabase.Dao.ReservationDao;
import com.example.localdatabase.Entity.Participant;
import com.example.localdatabase.Entity.Reservation;

@Database(entities = {Reservation.class, Participant.class}, version = 1, exportSchema = false)
public abstract class ReservationDatabase extends RoomDatabase {

    private static ReservationDatabase instance;

    public abstract ReservationDao reservationDao();

    public abstract ParticipantDao participantDao();

    public static synchronized ReservationDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            ReservationDatabase.class, "reservation_database")
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
    public static ReservationDatabase getDatabase(Context context) {
        if (instance == null) {
            synchronized (ReservationDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                                    ReservationDatabase.class, "reservation_database")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return instance;
    }

}

