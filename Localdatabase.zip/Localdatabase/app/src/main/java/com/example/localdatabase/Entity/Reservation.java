package com.example.localdatabase.Entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "reservations")
public class Reservation {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "reservation_time")
    private Date reservationTime;

    @ColumnInfo(name = "reservation_length")
    private int reservationLength;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "has_completed")
    private boolean hasCompleted;


    public Reservation(Date reservationTime, int reservationLength, String title, boolean hasCompleted) {
        this.reservationTime = reservationTime;
        this.reservationLength = reservationLength;
        this.title = title;
        this.hasCompleted = hasCompleted;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getReservationTime() {
        return reservationTime;
    }

    public void setReservationTime(Date reservationTime) {
        this.reservationTime = reservationTime;
    }

    public int getReservationLength() {
        return reservationLength;
    }

    public void setReservationLength(int reservationLength) {
        this.reservationLength = reservationLength;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isHasCompleted() {
        return hasCompleted;
    }

    public void setHasCompleted(boolean hasCompleted) {
        this.hasCompleted = hasCompleted;
    }
}

